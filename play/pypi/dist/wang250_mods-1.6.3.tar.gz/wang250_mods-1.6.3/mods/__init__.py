"""逃离王建国的模组依赖
by鸭皇
https://chenmy1903.github.io/wang250/
©chenmy1903
Github: 王建国
禁止盗用
"""

from .mod_tools import *
from .base_surface import Window
from .events import EventObject
from .test import test

from . import mod_tools, base_surface, events, test

__version__ = '1.6.3'
